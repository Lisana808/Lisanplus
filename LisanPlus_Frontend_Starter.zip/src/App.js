import React, { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Auth from './Auth';
import LisanPlusApp from './LisanPlusApp';
import ProtectedRoute from './ProtectedRoute';

export default function App() {
  const [user, setUser] = useState(null);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Auth onAuth={setUser} />} />
        <Route
          path="/"
          element={
            <ProtectedRoute user={user}>
              <LisanPlusApp user={user} />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}