import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Welcome to Lisan+</h1>
      <p>Arabic immersion across all dialects.</p>
    </div>
  );
}

export default App;
