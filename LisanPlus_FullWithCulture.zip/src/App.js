import React, { useState, useEffect } from 'react';

const lessonCategories = [
  { id: 'gulf', label: 'Gulf Arabic' },
  { id: 'egyptian', label: 'Egyptian Arabic' },
  { id: 'levantine', label: 'Levantine Arabic' },
  { id: 'maghrebi', label: 'Maghrebi Arabic' },
  { id: 'msa', label: 'Modern Standard Arabic' }
];

const userCompletedLessons = ['gulf_intro', 'msa_daily_dua'];

export default function App() {
  const [dialect, setDialect] = useState('gulf');
  const [input, setInput] = useState('');
  const [conversation, setConversation] = useState([]);
  const [faithMode, setFaithMode] = useState(false);
  const [username, setUsername] = useState('Guest');
  const [isListening, setIsListening] = useState(false);
  const [showWelcome, setShowWelcome] = useState(true);
  const [showCertificate, setShowCertificate] = useState(false);

  useEffect(() => {
    if (!('webkitSpeechRecognition' in window)) return;
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'ar-SA';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setInput(transcript);
    };

    if (isListening) {
      recognition.start();
    } else {
      recognition.stop();
    }

    return () => recognition.stop();
  }, [isListening]);

  const handleSend = () => {
    if (!input.trim()) return;
    const userMessage = { role: 'user', text: input };
    const botMessage = {
      role: 'bot',
      text: `You said: ${input} — here's how a native ${dialect} speaker might say it.`,
    };
    setConversation([...conversation, userMessage, botMessage]);
    setInput('');
  };

  if (showWelcome) {
    return (
      <div style={{ padding: '2rem', textAlign: 'center', fontFamily: 'sans-serif' }}>
        <h1>Welcome to Lisan+</h1>
        <p>In Depth Arabic immersion</p>
        <button onClick={() => setShowWelcome(false)}>Start Course</button>
  
<div style={{ marginTop: '2rem' }}>
  <h2>📅 Arabic Calendar & Cultural Insights</h2>
  <p>The Arabic calendar, also known as the Hijri calendar, is a lunar calendar consisting of 12 months in a year of 354 or 355 days. It began in the year 622 AD, when Prophet Muhammad ﷺ migrated from Mecca to Medina (Hijrah).</p>
  <ul style={{ marginTop: '1rem' }}>
    <li><strong>Muharram</strong> – Sacred month, first of the year.</li>
    <li><strong>Safar</strong> – Traditionally seen as unlucky, though no basis in Islam.</li>
    <li><strong>Rabi’ al-Awwal</strong> – The month of the Prophet’s birth.</li>
    <li><strong>Rajab</strong> – One of the four sacred months.</li>
    <li><strong>Sha’ban</strong> – Prepares for Ramadan.</li>
    <li><strong>Ramadan</strong> – Month of fasting, reflection, and Quran.</li>
    <li><strong>Dhu al-Hijjah</strong> – Hajj and Eid al-Adha.</li>
  </ul>
  <p style={{ marginTop: '1rem' }}>
    <strong>Cultural Norms to Know:</strong><br />
    - Hospitality is central; guests are honored.<br />
    - Elders are shown high respect.<br />
    - Avoid using the left hand for eating or greeting.<br />
    - Fridays (Jumu'ah) are sacred — many businesses close early.<br />
    - Modesty in dress is highly valued, especially in conservative areas.<br />
  </p>
</div>
    </div>
    );
  }

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1 style={{ textAlign: 'center' }}>Lisan+</h1>
      <p style={{ textAlign: 'center' }}>In Depth</p>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
        <button onClick={() => setFaithMode(!faithMode)}>
          {faithMode ? 'Faith Mode: ON' : 'Faith Mode: OFF'}
        </button>
        <span>User: {username}</span>
      </div>

      <div style={{ marginBottom: '1rem' }}>
        <h2>Lesson Categories</h2>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          {lessonCategories.map(cat => (
            <button
              key={cat.id}
              style={{
                backgroundColor: dialect === cat.id ? '#444' : '#eee',
                color: dialect === cat.id ? '#fff' : '#000',
                padding: '0.5rem 1rem',
                border: 'none',
                borderRadius: '5px'
              }}
              onClick={() => setDialect(cat.id)}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ marginBottom: '1rem' }}>
        <label>Speak or type:</label>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          style={{ width: '100%', height: '60px', marginTop: '0.5rem' }}
        />
        <br />
        <button onClick={() => setIsListening(!isListening)} style={{ marginTop: '0.5rem' }}>
          🎙️ {isListening ? 'Stop Listening' : 'Speak'}
        </button>
        <button onClick={handleSend} style={{ marginLeft: '1rem' }}>Send</button>
      </div>

      <div>
        {conversation.map((msg, i) => (
          <div key={i} style={{
            textAlign: msg.role === 'user' ? 'right' : 'left',
            background: msg.role === 'user' ? '#ddd' : '#f5f5f5',
            padding: '0.5rem',
            marginBottom: '0.5rem',
            borderRadius: '5px'
          }}>{msg.text}</div>
        ))}
      </div>

      <div style={{ marginTop: '2rem' }}>
        <h2>Lesson Tracker</h2>
        <ul>
          {lessonCategories.map(cat => (
            <li key={cat.id}>
              {cat.label} — {userCompletedLessons.includes(cat.id + '_intro') ? 'Completed' : 'Not started'}
            </li>
          ))}
        </ul>
        <button onClick={() => setShowCertificate(true)} style={{ marginTop: '1rem' }}>
          Generate Certificate
        </button>
      </div>

      {showCertificate && (
        <div style={{ marginTop: '2rem', border: '1px solid #aaa', padding: '1rem', borderRadius: '10px', background: '#fff' }}>
          <h3>📜 Certificate of Completion</h3>
          <p>This certifies that <strong>{username}</strong> has completed foundational lessons in Arabic through the Lisan+ program.</p>
          <p><small>Date: {new Date().toLocaleDateString()}</small></p>
        </div>
      )}
    </div>
  );
}
